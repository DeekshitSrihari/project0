//package com.revature.iba.exceptions;
//
//import java.util.InputMismatchException;
//
//public class CustomerInputMismatchException extends InputMismatchException {
//	public CustomerInputMismatchException() {
//		// TODO Auto-generated constructor stub
//	}
//	public CustomerInputMismatchException(String message) {
//		super(message);
//	}
//}
