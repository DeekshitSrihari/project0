package com;

public class App 
{
    public static void main( String[] args )
    {
    	InsightApp insightsApp=new InsightApp();
    	insightsApp.startInsightApp();
    }
}
